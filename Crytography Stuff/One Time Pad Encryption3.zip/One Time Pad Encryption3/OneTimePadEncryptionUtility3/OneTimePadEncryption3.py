#!/usr/bin/env python3
__author__ = 'marcsantiago'
from random import choice
from sys import stdout
from datetime import datetime

class OneTimePadEncryption3(object):
    """This Class was designed to apply a one time pad encryption
    on textual data that either comes from a file or that is entered
    manually by the user.  Note, the suffix of the key file and the suffix
    of the encrypted message file will be the same.  This allows
    users to associate key files with their corresponding
    encrypted text files"""

    def __init__(self):
        self.my_key = None
        self.my_string = None
        self.string_list = None
        self.key_list = None
        self.file_data = None
        self.timestamp = None

    def __string_converter(self, text_data):
        """Takes a given string or file and converts it to binary"""
        return bin(int.from_bytes(text_data.encode(), 'big'))

    def __key_generator(self, standard_string_length):
        """Generates a random list that is equal to
        the length of the provided string."""
        print("Generating Key Please Wait...")
        filename = "_".join(["key", self.timestamp])
        string_length = len(standard_string_length)
        key_list = []
        key_values = range(65, 123)
        for i in range(string_length):
            key_list.append(chr(choice(key_values)))

        with open(filename + ".dat", 'w') as data:
            temp_string = ""
            for key in key_list:
                temp_string += key
            data.write(temp_string)
        return self.__string_converter("".join(key_list))

    def decrypt_string_or_file(self, key, encrypted_string, key_file_mode=False, encrypted_string_file_mode=False):
        """Method that takes either the key or the encrypted string as a
        string or can the key and encrypted string a as file and decrypts
        the string using the provided string. NOTE** In order to use the the key.dat file
        you must first also be able to unzip it using a password."""
        print("Starting Decryption...")
        if key_file_mode is True:
            self.my_key = key
            with open(self.my_key, 'r') as key_data:
                self.my_key = key_data.read()
        else:
            self.my_key = key

        if encrypted_string_file_mode is True:
            self.my_string = encrypted_string
            with open(self.my_string, 'r') as string_data:
                self.my_string = string_data.read()
        else:
            self.my_string = encrypted_string

        my_string_num_list = self.my_string
        my_key_num_list = self.__string_converter(self.my_key)

        decrypt_list = []
        count = 2
        bar_length = 20
        for j in range(2, len(my_string_num_list)):
            percent = float(count) / len(my_key_num_list)
            hashes = "#" * int(round(percent * bar_length))
            spaces = " " * (bar_length - len(hashes))
            stdout.write("\rPercent: [{0}] {1}%".format(hashes + spaces, int(round(percent * 100))))
            stdout.flush()
            decrypt_list.append(int(my_string_num_list[j]) ^ int(my_key_num_list[j]))
            count += 1
        print()
        decrypt_list = [str(i) for i in decrypt_list]
        add_binary = "0b" + "".join(decrypt_list)
        decrypted_string = int(add_binary, 2)
        message =  decrypted_string.to_bytes((decrypted_string.bit_length() + 7) // 8, 'big').decode()

        with open("decrypted_message.txt", 'w') as out_message:
            out_message.write(str(message))
        print("Decryption Complete.")
        return message

    def encrypt_string_or_file(self, plain_text, string_file_mode=False):
        """Method that takes either the key or plaintext as a
        string or file. The key is randomly generated for you!"""
        print("Starting Encryption...")
        self.timestamp = str(datetime.now().strftime("%y%m%d_%H%M%S"))
        filename = "_".join(["encrypted_message", self.timestamp])
        if string_file_mode is True:
            with open(plain_text) as plaintext_data:
                self.file_data = str(plaintext_data.read())
                self.string_list = self.__string_converter(self.file_data)
                self.key_list = self.__key_generator(self.file_data)
        else:
            self.string_list = self.__string_converter(plain_text)
            self.key_list = self.__key_generator(plain_text)

        encrypted_list = []
        count = 2
        bar_length = 20
        for j in range(2, len(self.string_list)):
            percent = float(count) / len(self.string_list)
            hashes = "#" * int(round(percent * bar_length))
            spaces = " " * (bar_length - len(hashes))
            stdout.write("\rPercent: [{0}] {1}%".format(hashes + spaces, int(round(percent * 100))))
            stdout.flush()
            encrypted_list.append(int(self.string_list[j]) ^ int(self.key_list[j]))
            count += 1
        print()
        encrypted_list = [str(i) for i in encrypted_list]
        encrypted_data = "0b" + "".join(encrypted_list)

        with open(filename + ".txt", 'w') as message:
            message.write(encrypted_data)

        print("Encryption Complete.")
        return encrypted_data