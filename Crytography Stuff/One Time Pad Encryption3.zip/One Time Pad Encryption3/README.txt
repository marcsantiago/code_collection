AUTHOR: Marc Santiago
EMAIL: marcanthonysanti@gmail.com
This module is intended to provided users with a quick and simple way to
perform a one time pad encryption on text files and strings. 