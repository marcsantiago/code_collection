import os
from distutils.core import setup

def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()

setup(
  name = 'OneTimePadEncryption3',
  packages = ['OneTimePadEncryptionUtility3'],
  version = '1.0.0',
  author = 'Marc Santiago',
  author_email = 'marcanthonysanti@gmail.com',
  url = 'https://github.com/marcsantiago/one-time-pad-encryption', 
  download_url = 'https://github.com/marcsantiago/one-time-pad-encryption3/tarball/0.1', 
  keywords = ['encryption', 'one time pad', 'python3'],
  description = 'This module is intended to provided users with a quick and simple way to perform a one time pad encryption on text files and strings. Python3 Ready', 
  long_description=read('README.txt'),
  classifiers = [],
)